class AppStrings {
  static const appName = 'MaizeMate';
}
