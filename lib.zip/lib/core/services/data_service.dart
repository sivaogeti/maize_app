class DataService {
  // Placeholder for your repository / API client
  // Add real implementations later.
}
