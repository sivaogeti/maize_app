import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../core/services/auth_service.dart';
import 'package:provider/provider.dart';

class ClusterActivityScheduleListScreen extends StatelessWidget {
  const ClusterActivityScheduleListScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final cicUid = context.watch<AuthService>().currentUserIdOrAnon;

    final q = FirebaseFirestore.instance
        .collection('activity_schedule')
        .where('orgPathUids', arrayContains: cicUid)        // same org visibility
        .orderBy('createdAt', descending: true);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Activity Schedule Details'),
        leading: const BackButton(),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () => context.read<AuthService>().logout(),
          ),
        ],
      ),
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: q.snapshots(),
        builder: (ctx, snap) {
          if (snap.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snap.hasError) return Center(child: Text('Error: ${snap.error}'));
          final docs = snap.data?.docs ?? const [];
          if (docs.isEmpty) {
            return const Center(child: Text('No schedules visible.'));
          }

          return ListView.separated(
            itemCount: docs.length,
            separatorBuilder: (_, __) => const Divider(height: 1),
            itemBuilder: (ctx, i) {
              final d = docs[i];
              final m = d.data();
              final id     = m['id'] as String? ?? d.id;
              final farmer = (m['farmerName'] ?? m['farmerId'] ?? '') as String;
              final title  = (m['title'] ?? 'Crop Operation') as String;
              final status = (m['status'] ?? '') as String;

              return ListTile(
                leading: const Icon(Icons.event_note),
                title: Text(farmer.isEmpty ? id : farmer),
                subtitle: Text(title),
                trailing: Text(status.isEmpty ? '—' : status),
                onTap: () => context.push('/cic/activity-schedule/${d.id}'),
              );
            },
          );
        },
      ),
    );
  }
}
