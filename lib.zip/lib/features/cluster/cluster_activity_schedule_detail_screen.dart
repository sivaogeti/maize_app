import 'dart:convert';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import '../../core/services/auth_service.dart';

/// Change this if you prefer another collection name.
const String kActivityScheduleCollection = 'activity_schedule';

String _ymd(DateTime d) =>
    '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

class ClusterActivityScheduleDetailScreen extends StatelessWidget {
  const ClusterActivityScheduleDetailScreen({super.key});

  // Turn Firestore values into JSON-encodable values.
  /*dynamic _encodable(dynamic v) {
    if (v is Timestamp) return v.toDate().toIso8601String();       // "2025-10-05T00:00:00.000"
    if (v is DateTime) return v.toIso8601String();
    if (v is List) return v.map(_encodable).toList();
    if (v is Map) {
      return (v as Map).map((k, val) => MapEntry(k.toString(), _encodable(val)));
    }
    return v;                                                       // numbers, strings, bools…
  }*/

  @override
  Widget build(BuildContext context) {
    final uid = context.read<AuthService>().currentUser?.uid; // <- AppUser.id

    final q = FirebaseFirestore.instance
        .collection(kActivityScheduleCollection)
        .where('orgPathUids', arrayContains: uid)
        .orderBy('createdAt', descending: true);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Activity Schedules Details'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
            onPressed: () {
              if (context.canPop()) {
                context.pop();                 // go_router back
              } else {
                context.push('/');               // or your home: '/dashboard'
              }
            }
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            tooltip: 'Logout',
            onPressed: () async {
              try {
                await context.read<AuthService>().logout();
              } catch (e) {
                if (context.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Logout failed: $e')),
                  );
                }
              }
            },
          ),
        ],
      ),
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: q.snapshots(),
        builder: (context, snap) {
          if (snap.hasError) {
            // If you see a "query requires an index" error here, open the link
            // printed in the error to create a composite index:
            //   fields: createdBy (ASC), createdAt (DESC)
            return Padding(
              padding: const EdgeInsets.all(16),
              child: Text(
                'Error loading activity schedules:\n${snap.error}',
                style: const TextStyle(color: Colors.red),
              ),
            );
          }
          if (!snap.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          final docs = snap.data!.docs;
          if (docs.isEmpty) {
            return const Center(child: Text('No activity schedules yet'));
          }

          return ListView.separated(
            itemCount: docs.length,
            separatorBuilder: (_, __) => const Divider(height: 1),
            itemBuilder: (context, i) {
              final d = docs[i].data();

              // createdAt is typically a Timestamp
              DateTime created = DateTime.now();
              final raw = d['createdAt'];
              if (raw is Timestamp) {
                created = raw.toDate();
              } else if (raw is DateTime) {
                created = raw;
              } else if (raw != null) {
                created = DateTime.tryParse(raw.toString()) ?? created;
              }

              final farmer = (d['farmerOrFieldId'] ?? '').toString().trim();
              final kind = (d['kind'] ?? d['type'] ?? '').toString().trim(); // e.g. "activity" / "operation"

              return ListTile(
                leading: const Icon(Icons.view_list_outlined),
                title: Text(farmer.isEmpty ? '(no farmer selected)' : farmer),
                subtitle: Text('${_ymd(created)}${kind.isEmpty ? '' : '  •  $kind'}'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => showModalBottomSheet<void>(
                  context: context,
                  isScrollControlled: true,
                  builder: (_) => _DocPreviewSheet(data: d),
                ),
              );
            },
          );
        },
      ),
    );
  }
}

// Make Firestore values JSON-safe for pretty-printing
dynamic _jsonSafe(dynamic v) {
  if (v is Timestamp) return v.toDate().toIso8601String();
  if (v is GeoPoint) return {'lat': v.latitude, 'lng': v.longitude};
  if (v is Map) {
    return v.map((k, val) => MapEntry(k.toString(), _jsonSafe(val)));
  }
  if (v is List) {
    return v.map(_jsonSafe).toList();
  }
  return v;
}


class _DocPreviewSheet extends StatelessWidget {
  const _DocPreviewSheet({required this.data});

  final Map<String, dynamic> data;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Saved Activity Schedule',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
              const SizedBox(height: 12),
              // Simple, robust debug-style view (works regardless of exact schema)
              SelectableText(
                JsonEncoder.withIndent('  ').convert(_jsonSafe(data)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
