import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

import '../../core/services/auth_service.dart';

const String kActivityScheduleCollection = 'activity_schedule';


class ActivityScheduleDetailsScreen extends StatelessWidget {
  const ActivityScheduleDetailsScreen({
    super.key,
    required this.docId,
  });

  final String docId;

  CollectionReference<Map<String, dynamic>> get _col =>
      FirebaseFirestore.instance.collection(kActivityScheduleCollection);

  static String _str(dynamic v) {
    if (v == null) return '—';
    final s = v.toString().trim();
    return s.isEmpty ? '—' : s;
  }

  static String _fmtDate(dynamic v, {String pattern = 'yyyy-MM-dd'}) {
    if (v == null) return '—';
    if (v is Timestamp) return DateFormat(pattern).format(v.toDate());
    if (v is DateTime)  return DateFormat(pattern).format(v);
    final s = v.toString().trim();
    return s.isEmpty ? '—' : s; // allow preformatted strings like "2025-11-05"
  }

  DataTable _opsTable(List ops) {
    // columns match your edit UI: S.No | Operation | Responsible | Scheduled | Recommended | Completed | Remarks
    return DataTable(
      columns: const [
        DataColumn(label: Text('S.No')),
        DataColumn(label: Text('Operation')),
        DataColumn(label: Text('Responsible')),
        DataColumn(label: Text('Scheduled')),
        DataColumn(label: Text('Recommended')),
        DataColumn(label: Text('Completed')),
        DataColumn(label: Text('Remarks')),
      ],
      rows: [
        for (final raw in ops)
              () {
            final m = (raw as Map).cast<String, dynamic>();
            return DataRow(cells: [
              DataCell(Text(_str(m['sno'] ?? m['SNo']))),
              DataCell(Text(_str(m['operation'] ?? m['name']))),
              DataCell(Text(_str(m['responsible'] ?? m['by']))),
              DataCell(Text(_fmtDate(m['scheduled']))),
              DataCell(Text(_str(m['recommendedTiming'] ?? m['recommended']))),
              DataCell(Text(_fmtDate(m['completed']))),
              DataCell(Text(_str(m['remarks']))),
            ]);
          }(),
      ],
      headingTextStyle: const TextStyle(fontWeight: FontWeight.w600),
      dataRowMinHeight: 40,
      dataRowMaxHeight: 56,
      columnSpacing: 16,
      horizontalMargin: 12,
      showBottomBorder: true,
    );
  }

  DataTable _actsTable(List acts) {
    // columns: S.No | Crop Stage | Activity / Inputs | Supplier
    return DataTable(
      columns: const [
        DataColumn(label: Text('S.No')),
        DataColumn(label: Text('Crop Stage')),
        DataColumn(label: Text('Activity / Inputs')),
        DataColumn(label: Text('Supplier')),
      ],
      rows: [
        for (final raw in acts)
              () {
            final m = (raw as Map).cast<String, dynamic>();
            return DataRow(cells: [
              DataCell(Text(_str(m['sno'] ?? m['SNo']))),
              DataCell(Text(_str(m['stageLabel'] ?? m['stage'] ?? m['cropStage']))),
              DataCell(Text(_str(m['activityWithSuppliers'] ?? m['activity'] ?? m['inputs']))),
              DataCell(Text(_str(m['supplier'] ?? m['by'] ?? m['responsible']))),
            ]);
          }(),
      ],
      headingTextStyle: const TextStyle(fontWeight: FontWeight.w600),
      dataRowMinHeight: 40,
      dataRowMaxHeight: 56,
      columnSpacing: 16,
      horizontalMargin: 12,
      showBottomBorder: true,
    );
  }


  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Activity Schedule'),
          leading: IconButton(
              icon: const Icon(Icons.arrow_back),
              onPressed: () {
                if (context.canPop()) {
                  context.pop();                 // go_router back
                } else {
                  context.push('/');               // or your home: '/dashboard'
                }
              }
          ),
          actions: [
            // 2) Logout LAST
            IconButton(
              icon: const Icon(Icons.logout),
              tooltip: 'Logout',
              onPressed: () async {
                try {
                  await context.read<AuthService>().logout();
                } catch (e) {
                  if (context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Logout failed: $e')),
                    );
                  }
                }
              },
            ),
          ],
          bottom: const TabBar(
            tabs: [Tab(text: 'Crop Operation'), Tab(text: 'Crop Protection')],
            labelColor: Colors.white,            // <-- visible
            unselectedLabelColor: Colors.white70,
            indicatorColor: Colors.white,
          ),
        ),
        body: StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
          stream: _col.doc(docId).snapshots(),
          builder: (context, snap) {
            if (snap.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator());
            }
            if (!snap.hasData || !snap.data!.exists) {
              return const Center(child: Text('Schedule not found'));
            }

            final m    = snap.data!.data()!;
            final ops  = (m['operations'] as List?) ?? const [];
            final acts = (m['activities'] as List?) ?? const [];

            final String farmerFieldId = (m['farmerOrFieldId']
                ?? m['farmerFieldId']
                ?? m['farmerId']
                ?? m['fieldId']
                ?? '—').toString();

            Widget header() => Card(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: DropdownButtonFormField<String>(
                  value: farmerFieldId,
                  decoration: const InputDecoration(
                    labelText: 'Farmer / Field ID',
                    border: OutlineInputBorder(),
                  ),
                  items: [DropdownMenuItem(value: farmerFieldId, child: Text(farmerFieldId))],
                  onChanged: null, // read-only
                ),
              ),
            );

            DataTable opsTable(List list) => DataTable(
              columns: const [
                DataColumn(label: Text('S.No')),
                DataColumn(label: Text('Operation')),
                DataColumn(label: Text('Responsible')),
                DataColumn(label: Text('Scheduled')),
                DataColumn(label: Text('Recommended')),
                DataColumn(label: Text('Completed')),
                DataColumn(label: Text('Remarks')),
              ],
              rows: [
                for (final raw in list)
                      () {
                    final r = (raw as Map).cast<String, dynamic>();
                    String s(dynamic v) => (v == null || v.toString().trim().isEmpty) ? '—' : v.toString();
                    return DataRow(cells: [
                      DataCell(Text(s(r['sno'] ?? r['SNo']))),
                      DataCell(Text(s(r['operation'] ?? r['name']))),
                      DataCell(Text(s(r['responsible'] ?? r['by']))),
                      DataCell(Text(s(r['scheduled']))),
                      DataCell(Text(s(r['recommendedTiming'] ?? r['recommended']))),
                      DataCell(Text(s(r['completed']))),
                      DataCell(Text(s(r['remarks']))),
                    ]);
                  }(),
              ],
              headingTextStyle: const TextStyle(fontWeight: FontWeight.w600),
              columnSpacing: 16,
              horizontalMargin: 12,
              showBottomBorder: true,
            );

            DataTable actsTable(List list) => DataTable(
              columns: const [
                DataColumn(label: Text('S.No')),
                DataColumn(label: Text('Crop Stage')),
                DataColumn(label: Text('Activity / Inputs')),
                DataColumn(label: Text('Supplier')),
              ],
              rows: [
                for (final raw in list)
                      () {
                    final r = (raw as Map).cast<String, dynamic>();
                    String s(dynamic v) => (v == null || v.toString().trim().isEmpty) ? '—' : v.toString();
                    return DataRow(cells: [
                      DataCell(Text(s(r['sno'] ?? r['SNo']))),
                      DataCell(Text(s(r['stageLabel'] ?? r['stage'] ?? r['cropStage']))),
                      DataCell(Text(s(r['activityWithSuppliers'] ?? r['activity'] ?? r['inputs']))),
                      DataCell(Text(s(r['supplier'] ?? r['by'] ?? r['responsible']))),
                    ]);
                  }(),
              ],
              headingTextStyle: const TextStyle(fontWeight: FontWeight.w600),
              columnSpacing: 16,
              horizontalMargin: 12,
              showBottomBorder: true,
            );

            return TabBarView(
              children: [
                // Crop Operation
                ListView(
                  padding: const EdgeInsets.all(12),
                  children: [
                    header(),
                    const SizedBox(height: 8),
                    SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: opsTable(ops),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      'Saved on: ${_fmtDate(m['createdAt'], pattern: "yyyy-MM-dd HH:mm")}',
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                  ],
                ),
                // Crop Protection
                ListView(
                  padding: const EdgeInsets.all(12),
                  children: [
                    header(),
                    const SizedBox(height: 8),
                    SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: actsTable(acts),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      'Saved on: ${_fmtDate(m['createdAt'], pattern: "yyyy-MM-dd HH:mm")}',
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                  ],
                ),
              ],
            );
          },
        ),
      ),
    );

  }
}
