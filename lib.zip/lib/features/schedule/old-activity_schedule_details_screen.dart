import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

const String kActivityScheduleCollection = 'activity_schedule';


class ActivityScheduleDetailsScreen extends StatelessWidget {
  const ActivityScheduleDetailsScreen({
    super.key,
    required this.docId,
  });

  final String docId;

  CollectionReference<Map<String, dynamic>> get _col =>
      FirebaseFirestore.instance.collection(kActivityScheduleCollection);

  static String _str(dynamic v) {
    if (v == null) return '—';
    final s = v.toString().trim();
    return s.isEmpty ? '—' : s;
  }

  static String _fmtDate(dynamic v, {String pattern = 'yyyy-MM-dd'}) {
    if (v == null) return '—';
    if (v is Timestamp) return DateFormat(pattern).format(v.toDate());
    if (v is DateTime)  return DateFormat(pattern).format(v);
    final s = v.toString().trim();
    return s.isEmpty ? '—' : s; // allow preformatted strings like "2025-11-05"
  }

  DataTable _opsTable(List ops) {
    // columns match your edit UI: S.No | Operation | Responsible | Scheduled | Recommended | Completed | Remarks
    return DataTable(
      columns: const [
        DataColumn(label: Text('S.No')),
        DataColumn(label: Text('Operation')),
        DataColumn(label: Text('Responsible')),
        DataColumn(label: Text('Scheduled')),
        DataColumn(label: Text('Recommended')),
        DataColumn(label: Text('Completed')),
        DataColumn(label: Text('Remarks')),
      ],
      rows: [
        for (final raw in ops)
              () {
            final m = (raw as Map).cast<String, dynamic>();
            return DataRow(cells: [
              DataCell(Text(_str(m['sno'] ?? m['SNo']))),
              DataCell(Text(_str(m['operation'] ?? m['name']))),
              DataCell(Text(_str(m['responsible'] ?? m['by']))),
              DataCell(Text(_fmtDate(m['scheduled']))),
              DataCell(Text(_str(m['recommendedTiming'] ?? m['recommended']))),
              DataCell(Text(_fmtDate(m['completed']))),
              DataCell(Text(_str(m['remarks']))),
            ]);
          }(),
      ],
      headingTextStyle: const TextStyle(fontWeight: FontWeight.w600),
      dataRowMinHeight: 40,
      dataRowMaxHeight: 56,
      columnSpacing: 16,
      horizontalMargin: 12,
      showBottomBorder: true,
    );
  }

  DataTable _actsTable(List acts) {
    // columns: S.No | Activity | By | Scheduled | Completed | Remarks
    return DataTable(
      columns: const [
        DataColumn(label: Text('S.No')),
        DataColumn(label: Text('Activity')),
        DataColumn(label: Text('By')),
        DataColumn(label: Text('Scheduled')),
        DataColumn(label: Text('Completed')),
        DataColumn(label: Text('Remarks')),
      ],
      rows: [
        for (final raw in acts)
              () {
            final m = (raw as Map).cast<String, dynamic>();
            return DataRow(cells: [
              DataCell(Text(_str(m['sno'] ?? m['SNo']))),
              DataCell(Text(_str(m['activity'] ?? m['name']))),
              DataCell(Text(_str(m['by'] ?? m['responsible']))),
              DataCell(Text(_fmtDate(m['scheduled']))),
              DataCell(Text(_fmtDate(m['completed']))),
              DataCell(Text(_str(m['remarks']))),
            ]);
          }(),
      ],
      headingTextStyle: const TextStyle(fontWeight: FontWeight.w600),
      dataRowMinHeight: 40,
      dataRowMaxHeight: 56,
      columnSpacing: 16,
      horizontalMargin: 12,
      showBottomBorder: true,
    );
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Activity Schedule'),
          bottom: const TabBar(
            tabs: [
              Tab(text: 'Crop Operation'),
              Tab(text: 'Crop Protection'),
            ],
          ),
        ),
        body: StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
          stream: _col.doc(docId).snapshots(),
          builder: (context, snap) {
            if (snap.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator());
            }
            if (!snap.hasData || !snap.data!.exists) {
              return const Center(child: Text('Schedule not found'));
            }
            final m = snap.data!.data()!;
            final ops  = (m['operations'] as List?) ?? const [];
            final acts = (m['activities'] as List?) ?? const [];

            return TabBarView(
              children: [
                // Crop Operation
                ListView(
                  padding: const EdgeInsets.all(12),
                  children: [
                    _opsTable(ops),
                    const SizedBox(height: 12),
                    Text(
                      'Saved on: ${_fmtDate(m['createdAt'], pattern: 'yyyy-MM-dd HH:mm')}',
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                  ],
                ),
                // Crop Protection
                ListView(
                  padding: const EdgeInsets.all(12),
                  children: [
                    _actsTable(acts),
                    const SizedBox(height: 12),
                    Text(
                      'Saved on: ${_fmtDate(m['createdAt'], pattern: 'yyyy-MM-dd HH:mm')}',
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                  ],
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}
