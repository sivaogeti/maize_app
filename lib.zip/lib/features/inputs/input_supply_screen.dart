// lib/features/inputs/input_supply_screen.dart
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:provider/provider.dart';

import '../../core/models/input_issue.dart';
import '../../core/services/auth_service.dart'; // adjust path if different
import '../../core/services/farmers_provider.dart';
import '../../core/services/input_issues_provider.dart';
import 'inputs_details_screen.dart';

import 'dart:io';
import 'dart:typed_data';
import 'dart:convert';               // for base64Encode
import 'package:image_picker/image_picker.dart';
import 'package:signature/signature.dart';

import 'package:firebase_auth/firebase_auth.dart';


class InputSupplyScreen extends StatefulWidget {
  const InputSupplyScreen({super.key});

  @override
  State<InputSupplyScreen> createState() => _InputSupplyScreenState();
}

class _InputSupplyScreenState extends State<InputSupplyScreen> {
  DateTime _date = DateTime.now();         // use your current default if different
  final TextEditingController _dateCtrl = TextEditingController();

  String _fmt(DateTime d) =>
      '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  final _formKey = GlobalKey<FormState>();

  final _qtyIssuedCtrl = TextEditingController();     // NEW – used in _save()


  // Form fields
  final _farmerCtrl = TextEditingController();
  final _cropStageCtrl = TextEditingController();

  // Farmer list for dropdown
  List<String> _farmerIds = [];
  String? _selectedFarmerId;

  // Item fields
  String _itemType = 'Fertiliser';
  final _brandCtrl = TextEditingController();
  final _batchCtrl = TextEditingController();
  final _uomCtrl = TextEditingController(text: 'kg');
  final _qtyCtrl = TextEditingController();

  final _issuedByCtrl = TextEditingController();
  bool _receivedBy = false;
  final _advanceCtrl = TextEditingController();
  final _remarksCtrl = TextEditingController();

  final _imagePicker = ImagePicker();

  File? _photo;                         // farmer photo
  Uint8List? _signaturePng;             // exported signature PNG bytes

  // Signature controller — initialize at declaration (prevents LateInitializationError)
  final SignatureController _sigCtrl = SignatureController(
    penStrokeWidth: 3,
    penColor: Colors.black,
    exportBackgroundColor: Colors.white,
  );


  @override
  void initState() {
    super.initState();
    _dateCtrl.text = _fmt(_date);
    _loadFarmers();
    _loadLastFieldId();
    _loadFarmerIdItems();
  }

  // Turn a Firestore doc into (value,label) for the dropdown.
  ({String value, String label}) _docToOption(
      QueryDocumentSnapshot<Map<String, dynamic>> doc,
      ) {
    final m   = doc.data();
    final id  = (m['id'] as String?) ?? doc.id;
    final nm  = (m['name'] as String?) ?? '';
    final vil = (m['cropVillage'] as String?) ?? '';

    final label = [
      id,
      if (nm.isNotEmpty) '— $nm',
      if (vil.isNotEmpty) ' ($vil)',
    ].join('');

    return (value: id, label: label);
  }


  // In your State class:
  bool _farmerIdLoading = false;
  List<DropdownMenuItem<String>> _farmerIdItems = [];
  String? _farmerIdError; // optional
  // Farmer / Field list for the dropdown
  String? _farmerId; // whatever variable your dropdown already uses
  bool _loadingFarmers = false;

  Future<void> _loadFarmerIdItems() async {
    setState(() {
      _farmerIdLoading = true;
      _farmerIdError = null;
    });

    try {
      // Ensure we have a logged-in user BEFORE querying
      final user = FirebaseAuth.instance.currentUser ??
          await FirebaseAuth.instance
              .authStateChanges()
              .firstWhere((u) => u != null);
      final uid = user!.uid;

      final db = FirebaseFirestore.instance;

      // Query both collections in parallel
      final results = await Future.wait([
        db
            .collection('farmers')
            .where('orgPathUids', arrayContains: uid)
            .orderBy('createdAt', descending: true)
            .limit(200)
            .get(),
        db
            .collection('farmer_registrations')
            .where('orgPathUids', arrayContains: uid)
            .orderBy('createdAt', descending: true)
            .limit(200)
            .get(),
      ]);

      final farmersSnap = results[0];
      final regsSnap    = results[1];

      final items = <DropdownMenuItem<String>>[
        ...farmersSnap.docs.map((d) => DropdownMenuItem(
          value: d.id,
          child: Text(d.id, overflow: TextOverflow.ellipsis),
        )),
        ...regsSnap.docs.map((d) => DropdownMenuItem(
          value: d.id,
          child: Text(d.id, overflow: TextOverflow.ellipsis),
        )),
      ];

      if (!mounted) return;
      setState(() {
        _farmerIdItems = items;
        _farmerIdLoading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _farmerIdError = e.toString();
        _farmerIdLoading = false;
      });
    }
  }




  Future<void> _loadFarmers() async {
    try {
      // Get your provider instance
      final fp = context.read<FarmersProvider>();

      // Be tolerant to different provider shapes (farmers / list / views, etc.)
      final dynamic any = fp;
      final Iterable<dynamic> farmers =
      (any.farmers ?? any.list ?? any.views ?? const <dynamic>[]) as Iterable<dynamic>;

      // Map to String IDs robustly
      final ids = farmers
          .map<String>((f) {
        if (f is String) return f;                // already an id
        if (f is Map) {                            // map-shaped
          final v = (f['id'] ?? f['farmerId'] ?? f['farmer_id']);
          return v == null ? '' : v.toString();
        }
        try {                                      // object with .id
          final id = (f as dynamic).id;
          if (id is String) return id;
          return id?.toString() ?? '';
        } catch (_) {
          return '';
        }
      })
          .where((s) => s.isNotEmpty)
          .toSet()                                     // dedupe, optional
          .toList(growable: false);

      if (!mounted) return;
      setState(() => _farmerIds = ids);
    } catch (e) {
      debugPrint('loadFarmers failed: $e');
      if (!mounted) return;
      setState(() => _farmerIds = const []);
    }
  }

  void _clearForm() {
    setState(() {
      // date
      _date = DateTime.now();

      // farmer & crop
      _selectedFarmerId = null;
      _cropStageCtrl.clear();

      // item details
      _itemType = ''; // or 'Fertiliser' if you want a default
      _brandCtrl.clear();
      _batchCtrl.clear();
      _uomCtrl.text = 'kg'; // or whatever default you use
      _qtyIssuedCtrl.clear();

      // issuer / receiver
      _issuedByCtrl.clear();
      _receivedBy = false;

      // finance & remarks
      _advanceCtrl.clear();
      _remarksCtrl.clear();

      // attachments
	  _signaturePng = null;
      _photo = null;

      // signature
      _sigCtrl.clear();
    });
  }



  Future<void> _loadLastFieldId() async {
    final prefs = await SharedPreferences.getInstance();
    final last = prefs.getString('last_farmer_or_field_id');
    if (last != null && mounted) {
      _farmerCtrl.text = last;
    }
  }

  Future<void> _saveLastFieldId(String id) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('last_farmer_or_field_id', id);
  }

  @override
  void dispose() {
    _farmerCtrl.dispose();
    _cropStageCtrl.dispose();
    _brandCtrl.dispose();
    _batchCtrl.dispose();
    _uomCtrl.dispose();
    _qtyCtrl.dispose();
    _issuedByCtrl.dispose();
    _advanceCtrl.dispose();
    _remarksCtrl.dispose();
    _dateCtrl.dispose();
    _sigCtrl.dispose();
    _qtyIssuedCtrl.dispose();
    super.dispose();
  }

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _date,
      firstDate: DateTime(2020, 1, 1),
      lastDate: DateTime(2100, 12, 31),
    );
    if (picked != null) {
      setState(() {
        _date = picked;
        _dateCtrl.text = _fmt(_date);
      });
    }
  }

  Future<void> _pickPhoto() async {
    final x = await _imagePicker.pickImage(
      source: ImageSource.camera, // or .gallery if you prefer
      imageQuality: 75,
      maxWidth: 1600,
    );
    if (x != null) setState(() => _photo = File(x.path));
  }

  // Safe exporter: won’t setState after dispose or crash on empty
  Future<void> _exportSignature() async {
    if (_sigCtrl.isEmpty) {
      if (!mounted) return;
      setState(() => _signaturePng = null);
      return;
    }
    try {
      final png = await _sigCtrl.toPngBytes();
      if (!mounted) return;
      if (png != null) {
        setState(() => _signaturePng = png);
      }
    } catch (_) {
      // ignore if controller got disposed during await
    }
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;

    try {
      // Use FirebaseAuth directly to avoid AppUser shape mismatches
      final uid = FirebaseAuth.instance.currentUser?.uid ?? '';

      // Signature → base64 (safe if user didn’t draw)
      final sigBytes = await _sigCtrl.toPngBytes();
      final signatureB64 = sigBytes == null ? null : base64Encode(sigBytes);

      final payload = <String, dynamic>{
        'dateOfIssue': Timestamp.fromDate(_date),                 // _date is DateTime
        'farmerOrFieldId': (_selectedFarmerId ?? '').trim(),      // from your dropdown
        'cropAndStage': _cropStageCtrl.text.trim(),
        'itemType': _itemType,                                    // dropdown value
        'brandOrGrade': _brandCtrl.text.trim(),
        'batchOrLotNo': _batchCtrl.text.trim(),
        'unitOfMeasure': _uomCtrl.text.trim(),
        'quantityIssued': double.tryParse(_qtyIssuedCtrl.text.trim()) ?? 0,
        'issuedBy': _issuedByCtrl.text.trim(),
        'receivedBy': _receivedBy,                                // bool
        'advanceAmount': _advanceCtrl.text.trim().isEmpty
            ? null
            : double.tryParse(_advanceCtrl.text.trim()),
        'remarks': _remarksCtrl.text.trim().isEmpty
            ? null
            : _remarksCtrl.text.trim(),
        'photoPath': _photo?.path,                                // we’ll upgrade to Storage later
        'signaturePng': signatureB64,
        'createdBy': uid,
      };

      await context.read<InputIssuesProvider>().addIssue(payload);


      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Input supply saved')),
      );

      //Clearing Form after save succeeds
      _clearForm();

      // Optional: navigate back or to list
      // context.go('/inputs-details');
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Save failed: $e')),
      );
    }
  }


  void _openDetails() {
    context.push('/inputs/inputs_details/saved'); // adjust to your route if different
  }

  String? _req(String? v) => (v == null || v.trim().isEmpty) ? 'Required' : null;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Input Supply Tracker'),
        leading: Builder(
          builder: (ctx) {
            // If we can pop, just show the normal back button.
            if (Navigator.of(ctx).canPop()) {
              return const BackButton();
            }
            // If this is the root, provide a manual back-to-dashboard fallback.
            return IconButton(
              icon: const Icon(Icons.arrow_back),
              tooltip: 'Back',
              onPressed: () {
                final r = GoRouter.of(context);
                if (r.canPop()) {
                  r.pop();                       // go_router back
                } else if (Navigator.of(context).canPop()) {
                  Navigator.of(context).pop();    // plain Navigator back (just in case)
                } else {
                  context.go('/');                // ✅ fallback to your Home route
                }
              },
            );
          },
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.list_alt),
            tooltip: 'View Details',
            onPressed: _openDetails,
          ),
          IconButton(
            icon: const Icon(Icons.logout),
            tooltip: 'Logout',
            onPressed: () {
              try {
                context.read<AuthService>().logout();
              } catch (e) {
                if (context.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Logout failed: $e')),
                  );
                }
              }
            },
          ),
        ],
      ),
      body: SafeArea(
        child: Form(
          key: _formKey,
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Date
                TextFormField(
                  controller: _dateCtrl,
                  readOnly: true,
                  decoration: const InputDecoration(
                    labelText: 'Date',
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.event),
                  ),
                  onTap: _pickDate,
                ),
                const SizedBox(height: 12),

                // Farmer / Field ID
                DropdownButtonFormField<String>(
                  value: _farmerId,
                  items: _farmerIdItems,
                  onChanged: (v) => setState(() => _farmerId = v),
                  isExpanded: true,
                  decoration: const InputDecoration(
                    labelText: 'Farmer / Field ID',
                    prefixIcon: Icon(Icons.badge_outlined),
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 12),

                // Crop & Stage
                TextFormField(
                  controller: _cropStageCtrl,
                  decoration: const InputDecoration(
                    labelText: 'Crop & Stage',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 16),

                // Item details
                _sectionHeader('Item Details'),
                const SizedBox(height: 8),
                DropdownButtonFormField<String>(
                  value: _itemType,
                  decoration: const InputDecoration(
                    labelText: 'Item Type',
                    border: OutlineInputBorder(),
                  ),
                  items: const [
                    DropdownMenuItem(value: 'Fertiliser', child: Text('Fertiliser')),
                    DropdownMenuItem(value: 'Pesticide', child: Text('Pesticide')),
                    DropdownMenuItem(value: 'Seed', child: Text('Seed')),
                    DropdownMenuItem(value: 'Other', child: Text('Other')),
                  ],
                  onChanged: (v) => setState(() => _itemType = v ?? 'Fertiliser'),
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Expanded(
                      child: TextFormField(
                        controller: _brandCtrl,
                        decoration: const InputDecoration(
                          labelText: 'Brand / Grade',
                          border: OutlineInputBorder(),
                        ),
                        validator: _req,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: TextFormField(
                        controller: _batchCtrl,
                        decoration: const InputDecoration(
                          labelText: 'Batch / Lot No.',
                          border: OutlineInputBorder(),
                        ),
                        validator: _req,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Expanded(
                      child: TextFormField(
                        controller: _uomCtrl,
                        decoration: const InputDecoration(
                          labelText: 'Unit of Measure',
                          border: OutlineInputBorder(),
                        ),
                        validator: _req,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: TextFormField(
                        controller: _qtyCtrl,
                        keyboardType: TextInputType.number,
                        decoration: const InputDecoration(
                          labelText: 'Quantity Issued',
                          border: OutlineInputBorder(),
                        ),
                        validator: _req,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),

                // Issuer / Receiver
                _sectionHeader('Issuer & Receiver'),
                const SizedBox(height: 8),
                TextFormField(
                  controller: _issuedByCtrl,
                  decoration: const InputDecoration(
                    labelText: 'Issued By (Cluster/Territory incharge/manager)',
                    border: OutlineInputBorder(),
                  ),
                  validator: _req,
                ),
                const SizedBox(height: 8),
                SwitchListTile(
                  title: const Text('Received By (Farmer Sign / Photo)'),
                  value: _receivedBy,
                  onChanged: (v) => setState(() => _receivedBy = v),
                ),
                const SizedBox(height: 12),

                // --- Attachments ---
                Padding(
                  padding: const EdgeInsets.fromLTRB(8, 16, 8, 8),
                  child: Text(
                    'Attachments',
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.w600,
                      color: Theme.of(context).colorScheme.onSurfaceVariant,
                    ),
                  ),
                ),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    OutlinedButton.icon(
                      onPressed: _pickPhoto,
                      icon: const Icon(Icons.camera_alt_outlined),
                      label: const Text('Farmer Photo'),
                    ),
                    if (_photo != null)
                      ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: Image.file(_photo!, height: 120, fit: BoxFit.cover),
                      ),
                  ],
                ),
                const SizedBox(height: 12),

                // --- Signature ---
                Padding(
                  padding: const EdgeInsets.fromLTRB(8, 16, 8, 8),
                  child: Text(
                    'Signature',
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.w600,
                      color: Theme.of(context).colorScheme.onSurfaceVariant,
                    ),
                  ),
                ),
                Container(
                  height: 160,
                  decoration: BoxDecoration(
                    border: Border.all(color: Theme.of(context).dividerColor),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Signature(
                    controller: _sigCtrl,
                    backgroundColor: Colors.white,
                  ),
                ),
                const SizedBox(height: 8),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    TextButton.icon(
                      onPressed: () => _sigCtrl.clear(),
                      icon: const Icon(Icons.clear),
                      label: const Text('Clear Signature'),
                    ),
                    ElevatedButton.icon(
                      onPressed: _sigCtrl.isNotEmpty ? () async => await _exportSignature() : null,
                      icon: const Icon(Icons.check),
                      label: const Text('Use'),
                    ),
                  ],
                ),
                const SizedBox(height: 16),

                // Finance & Remarks
                _sectionHeader('Finance & Remarks'),
                const SizedBox(height: 8),
                TextFormField(
                  controller: _advanceCtrl,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    labelText: 'Advance amount',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 8),
                TextFormField(
                  controller: _qtyIssuedCtrl,                     // <— hook it up
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    labelText: 'Quantity Issued',
                    border: OutlineInputBorder(),
                  ),
                  validator: (v) => (v == null || v.trim().isEmpty) ? 'Required' : null,
                ),
                const SizedBox(height: 8),
                TextFormField(
                  controller: _remarksCtrl,
                  decoration: const InputDecoration(
                    labelText: 'Remarks',
                    border: OutlineInputBorder(),
                  ),
                  maxLines: 3,
                ),
                const SizedBox(height: 16),

                Row(
                  children: [
                    Expanded(
                      child: ElevatedButton(
                        onPressed: _save,
                        child: const Text('Save Supply'),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: OutlinedButton(
                        onPressed: _openDetails,
                        child: const Text('View Details'),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 24),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _sectionHeader(String title) => Padding(
    padding: const EdgeInsets.fromLTRB(8, 0, 8, 0),
    child: Text(
      title,
      style: Theme.of(context).textTheme.titleMedium?.copyWith(
        fontWeight: FontWeight.w600,
      ),
    ),
  );
}
