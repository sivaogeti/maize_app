// lib/features/inputs/inputs_details_screen.dart
import 'dart:io';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../core/models/input_issue.dart';

import 'dart:typed_data';

import 'package:provider/provider.dart';
import 'package:cloud_firestore/cloud_firestore.dart';  // for Timestamp -> Date
import '../../core/services/input_issues_provider.dart';

import 'package:intl/intl.dart';
import 'package:cloud_firestore/cloud_firestore.dart' show Timestamp;



const _kInputsKey = 'inputs_issues_v1';

class InputsDetailsScreen extends StatefulWidget {
  const InputsDetailsScreen({super.key});

  @override
  State<InputsDetailsScreen> createState() => _InputsDetailsScreenState();
}

class _InputsDetailsScreenState extends State<InputsDetailsScreen> {
  DateTime _date = DateTime.now();
  late final TextEditingController _dateCtrl;

  String _fmtDate(DateTime d) =>
      '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  List<InputIssue> _rows = [];

  // Formats either a Firestore Timestamp or a DateTime to yyyy-MM-dd
  final DateFormat _df = DateFormat('yyyy-MM-dd');

  String _fmt(dynamic v) {
    if (v == null) return '';
    try {
      if (v is Timestamp) return _df.format(v.toDate());
      if (v is DateTime)  return _df.format(v);
      return v.toString();
    } catch (_) {
      return v.toString();
    }
  }


  @override
  void initState() {
    _dateCtrl = TextEditingController(text: _fmtDate(_date));
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _dateCtrl.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final list = prefs.getStringList(_kInputsKey) ?? <String>[];
    setState(() {
      _rows = list.map((e) => InputIssue.fromJson(jsonDecode(e))).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    final items = context.watch<InputIssuesProvider>().items;

    String _fmt(dynamic v) {
      if (v == null) return '';
      try {
        if (v is Timestamp) {
          return DateFormat('yyyy-MM-dd').format(v.toDate());
        }
        if (v is DateTime) {
          return DateFormat('yyyy-MM-dd').format(v);
        }
        return v.toString();
      } catch (_) {
        return v.toString();
      }
    }


    return Scaffold(
      appBar: AppBar(
        title: const Text('Inputs Details'),
        automaticallyImplyLeading: false,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: _smartBack,
          tooltip: 'Back',
        ),
        actions: [
          IconButton(
            tooltip: 'Refresh',
            onPressed: _load,
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      body: Consumer<InputIssuesProvider>(
        builder: (context, prov, _) {
          final items = prov.items; // live Firestore stream

          if (items.isEmpty) {
            return const Center(child: Text('No input issues yet'));
          }

          return ListView.separated(
            padding: const EdgeInsets.fromLTRB(12, 12, 12, 12),
            itemCount: items.length,
            separatorBuilder: (_, __) => const Divider(height: 1),
            itemBuilder: (_, i) {
              final it = items[i];           // InputIssueView
              final d  = it.raw;            // Map<String, dynamic>

              final id   = (d['farmerOrFieldId'] ?? '') as String;
              final when = (d['dateOfIssue'] is Timestamp)
                  ? (d['dateOfIssue'] as Timestamp).toDate()
                  : DateTime.now();
              final itemType = (d['itemType'] ?? '') as String;
              final qty = (d['quantityIssued'] ?? 0).toString();

              return ListTile(
                leading: const Icon(Icons.inventory_2_outlined),
                title: Text('$id • $itemType'),
                subtitle: Text('${_fmt(d['dateOfIssue'])}  •  Qty: ${(d['quantityIssued'] ?? 0).toString()}'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => _showIssueDetails(context as BuildContext, it), // keep your detail/sheet
              );
            },
          );
        },
      ),
    );
  }

  void _smartBack() {
    try {
      if (context.canPop()) {
        Navigator.of(context).maybePop();
        return;
      }
    } catch (_) {}
    if (Navigator.of(context).canPop()) {
      Navigator.of(context).pop();
      return;
    }
    final root = Navigator.of(context, rootNavigator: true);
    if (root.canPop()) root.pop();
  }

  Widget _issuesTable() {
    final columns = [
      'Date of Issue',
      'Farmer / Field ID',
      'Crop & Stage',
      'Item Type',
      'Brand / Grade',
      'Batch / Lot No.',
      'Unit of Measure',
      'Quantity Issued',
      'Photo',
      'Sig',
      'Issued By (Cluster/Territory incharge/manager)',
      'Received By (Farmer Sign / Photo)',
      'Advance amount',
      'Remarks',
    ];

    return DataTable(
      columns: columns
          .map((c) => DataColumn(
        label: Text(
          c,
          style: const TextStyle(fontWeight: FontWeight.w600),
        ),
      ))
          .toList(),
      rows: _rows.map((r) {
        return DataRow(
          onSelectChanged: (_) => _showIssueDetails(context, r as InputIssueView),
          cells: [
            DataCell(Text(_fmtDate(r.dateOfIssue))),
            DataCell(Text(r.farmerOrFieldId)),
            DataCell(Text(r.cropAndStage)),
            DataCell(Text(r.itemType)),
            DataCell(Text(r.brandOrGrade)),
            DataCell(Text(r.batchOrLotNo)),
            DataCell(Text(r.unitOfMeasure)),
            DataCell(Text(r.quantityIssued.toStringAsFixed(0))),
            DataCell(_photoCell(r)),
            DataCell(_sigCell(r)),
            DataCell(Text(r.issuedBy)),
            DataCell(Text(r.receivedBy ? 'Y' : '—')),
            DataCell(Text(r.advanceAmount?.toStringAsFixed(0) ?? '—')),
            DataCell(Text(r.remarks ?? '')),
          ],
        );
      }).toList(),
      headingRowColor: MaterialStateProperty.resolveWith(
            (states) => Theme.of(context).colorScheme.surfaceVariant,
      ),
      dataRowMinHeight: 48,
      dataRowMaxHeight: 64,
      columnSpacing: 20,
      showBottomBorder: true,
    );
  }

  Widget _photoCell(InputIssue r) {
    final path = r.photoPath ?? '';
    if (path.isEmpty) return const Icon(Icons.photo_outlined, size: 18);
    return ClipRRect(
      borderRadius: BorderRadius.circular(6),
      child: Image.file(
        File(path),
        width: 36,
        height: 36,
        fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => const Icon(Icons.broken_image, size: 18),
      ),
    );
  }

  Widget _sigCell(InputIssue r) {
    final hasSig = (r.signaturePng ?? '').isNotEmpty;
    return Icon(hasSig ? Icons.gesture : Icons.gesture_outlined, size: 18);
    // If you want a small thumbnail of the signature instead,
    // decode and return an Image.memory here.
  }

  void _showIssueDetails(BuildContext context, InputIssueView it) {
    final d = it.raw; // Map<String, dynamic> from the provider
    final String? photoPath   = (d['photoPath'] as String?)?.trim();
    final String? signatureB64= (d['signaturePng'] as String?)?.trim();

    Uint8List? sigBytes;
    if (signatureB64 != null && signatureB64.isNotEmpty) {
      try { sigBytes = base64Decode(signatureB64); } catch (_) {}
    }

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (_) {
        Widget kv(String k, String v) => Padding(
          padding: const EdgeInsets.symmetric(vertical: 6),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(width: 130, child: Text(k, style: const TextStyle(fontWeight: FontWeight.w600))),
              const SizedBox(width: 8),
              Expanded(child: Text(v)),
            ],
          ),
        );

        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 20),
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Icon(Icons.inventory_2_outlined),
                      const SizedBox(width: 8),
                      Text('Input Supply Details', style: Theme.of(context).textTheme.titleLarge),
                    ],
                  ),
                  const SizedBox(height: 12),
                  const Divider(),

                  kv('Date', _fmt(d['dateOfIssue'])),
                  kv('Farmer / Field ID', (d['farmerOrFieldId'] ?? '').toString()),
                  kv('Crop & Stage', (d['cropAndStage'] ?? '').toString()),

                  const Divider(),
                  kv('Item Type', (d['itemType'] ?? '').toString()),
                  kv('Brand / Grade', (d['brandOrGrade'] ?? '').toString()),
                  kv('Batch / Lot No.', (d['batchOrLotNo'] ?? '').toString()),
                  kv('Unit of Measure', (d['unitOfMeasure'] ?? '').toString()),
                  kv('Quantity Issued', (d['quantityIssued'] ?? 0).toString()),

                  const Divider(),
                  kv('Issued By', (d['issuedBy'] ?? '').toString()),
                  kv('Received By', (d['receivedBy'] ?? '').toString()),

                  if ((d['advanceAmount'] ?? '').toString().isNotEmpty) kv('Advance Amount', d['advanceAmount'].toString()),
                  if ((d['remarks'] ?? '').toString().isNotEmpty) kv('Remarks', (d['remarks'] ?? '').toString()),

                  if ((photoPath ?? '').isNotEmpty) ...[
                    const SizedBox(height: 12),
                    Text('Attachment', style: Theme.of(context).textTheme.titleMedium),
                    const SizedBox(height: 8),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: Image.file(File(photoPath!), height: 160, fit: BoxFit.cover),
                    ),
                  ],

                  if (sigBytes != null) ...[
                    const SizedBox(height: 12),
                    Text('Signature', style: Theme.of(context).textTheme.titleMedium),
                    const SizedBox(height: 8),
                    Container(
                      height: 140,
                      decoration: BoxDecoration(
                        border: Border.all(color: Theme.of(context).dividerColor),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Image.memory(sigBytes, fit: BoxFit.contain),
                    ),
                  ],

                  const SizedBox(height: 16),
                  Align(
                    alignment: Alignment.centerRight,
                    child: OutlinedButton.icon(
                      icon: const Icon(Icons.close),
                      label: const Text('Close'),
                      onPressed: () => Navigator.of(context).pop(),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }


  Widget _kv(String k, String v) => Padding(
    padding: const EdgeInsets.only(bottom: 8),
    child: Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
            width: 140,
            child: Text(k,
                style:
                const TextStyle(fontWeight: FontWeight.w600))),
        const SizedBox(width: 8),
        Expanded(child: Text(v.isEmpty ? '—' : v)),
      ],
    ),
  );
}
